var questions=[
		"Whats your Name ?",
		"Where are you from ?",
		"What is your work experience ? It would be nice if you enter in Years",
		"Which technology you are working on",
		"It was nice talking to you"
	];
	var qNum=0;
	var question=document.querySelector("#question");
	var answer=document.querySelector("#answer");
	question.innerHTML=questions[qNum];
	var callChangeQuestion= function(){
		answer.value="";
		++qNum;
		setTimeout(changeQuestion, 2000); 
	}
	function showResponse(){
		var inputValue=answer.value;
		if(inputValue==""){
			
		}else{
			switch(qNum){
				case 0:			
					question.innerHTML=`Nice to meet you ${inputValue}`;
					callChangeQuestion();
					break;
				case 1:			
					question.innerHTML=`${inputValue} is an awesome place`;
					callChangeQuestion();
					break;
				case 2:			
					question.innerHTML=`Great, ${inputValue} years is a very impressive experience`;
					callChangeQuestion();
					break;
				case 3:			
					question.innerHTML=`${inputValue} is a good language. You people are rocking the market now`;
					callChangeQuestion();
					break;
				default:
					callChangeQuestion();
			}	
		}
	}
	function changeQuestion(){
		question.innerHTML=questions[qNum];
		if((questions.length-1)==qNum) {
			answer.style.display="none";
		}
	}
	

	$(document).on('keypress', function(e){
		if(e.which==13){
			showResponse();
		}
	});